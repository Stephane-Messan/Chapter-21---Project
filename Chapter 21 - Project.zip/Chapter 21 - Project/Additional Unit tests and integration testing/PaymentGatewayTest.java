import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class PaymentGatewayTest {

    @Test
    public void testProcessPayment() {
        PaymentGateway gateway = new PaymentGateway();
        assertTrue(gateway.processPayment(50.0));
    }
}
