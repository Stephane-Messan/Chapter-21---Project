import java.io.Serializable;
import java.util.List;

class Order implements Serializable {
    private int orderId;
    private List<Book> orderedBooks;
    private double totalAmount;

    public Order(int orderId, List<Book> orderedBooks, double totalAmount) {
        this.orderId = orderId;
        this.orderedBooks = orderedBooks;
        this.totalAmount = totalAmount;
    }

    public int getOrderId() {
        return orderId;
    }

    public List<Book> getOrderedBooks() {
        return orderedBooks;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    @Override
    public String toString() {
        StringBuilder orderDetails = new StringBuilder(orderId + ",");
        for (Book book : orderedBooks) {
            orderDetails.append(book.toString()).append(";");
        }
        orderDetails.append(totalAmount);
        return orderDetails.toString();
    }
}
