import java.util.ArrayList;
import java.util.List;

class ShoppingCart {
    private List<Book> books;

    public ShoppingCart() {
        this.books = new ArrayList<>();
    }

    public void addToCart(Book book) {
        books.add(book);
    }

     public List<Book> getBooks() {
	        return books;
    }

    public double calculateTotalPrice() {
        double total = 0;
        for (Book book : books) {
            total += book.getPrice();
        }
        return total;
    }

    public void clearCart() {
        books.clear();
    }
}
